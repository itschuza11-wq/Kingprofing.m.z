import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center">
      <h1 className="text-4xl font-extrabold mb-6">Welcome to Kingprofit</h1>
      <p className="mb-6 max-w-xl text-center text-gray-700">
        User demo page — configure Supabase keys in .env.local or Vercel.
      </p>

      <div className="flex gap-4">
        <Link href="/admin" className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
          Go to Admin Panel
        </Link>
      </div>
    </main>
  );
}
